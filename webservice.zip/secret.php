<?php
include("Fffffff4ggggggg.php");
$flag="MemberCTF{rob0t_V1!good_1Uck";
if(isset($_GET["char"]) &&!empty($_GET["char"])){

    $char=$_GET["char"];
    if ($flag.$char."}"===$real_flag){
    	echo "GOOD JOB BABY : ".$real_flag;

    }
    
}
?>