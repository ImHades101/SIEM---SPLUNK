<?php
$real_flag="MemberCTF{rob0t_V1!good_1Uck137}";
?>