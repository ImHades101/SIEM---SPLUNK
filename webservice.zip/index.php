<?php 

//detect xss
function dtXSS($endpoint,$payload,$method){
  
  $date = date('Y-m-d H:i:s');
  if(preg_match("/(?=.*<[a-z])(?=.*(>|<|alert|print|onload|fetch|\/|src|\+|\"|\'))(?=.*>)/i",$payload) || preg_match("/(?=.*(\"|\'))(?=.*(alert|print|onload|fetch|document|\/|src|\+|\-|\*|\/|\[))(?=.*(\(|\)|`))/i",$payload )) {
    $file = fopen("/var/log/webvuln.log","a");
    fwrite($file,"- [Time]: ".$date." #[Attacker's IP]: ".$_SERVER['REMOTE_ADDR']." #[Detected]: XSS attack!! # [Endpoint]: /".$method."/ = ".$endpoint." # [Payload]: ".$payload."\n");
    fclose($file);
  }

}
//detect sqli
function dtSQLI($endpoint,$payload,$method){
  $date = date('Y-m-d H:i:s');
  if(preg_match("/(?=.*(select|union|\;?insert|substr|if|or|and|left|right|mid|spleep|BENCHMARK))(?=.*(from|\(|\,|-|\"|\'|set|1|\=|select|value|md5|rand|\>))/i",$payload) || preg_match("/(?=.*(\"|\'))(?=.*(or|and|\-\-|\#|\%|union|select|substr|\(|spleep|\=|from|value|\|\||\&))/i",$payload )) {
    $payload= preg_replace("/\n/","%0d%0a",$payload );
    $file = fopen("/var/log/webvuln.log","a");
    fwrite($file,"- [Time]: ".$date." #[Attacker's IP]: ".$_SERVER['REMOTE_ADDR']." #[Detected]: SQLI attack!! # [Endpoint]: /".$method."/ = ".$endpoint." # [Payload]: ".$payload."\n");
    fclose($file);
  }

}
//detect RCE
function dtRCE($endpoint,$payload,$method){
  $date = date('Y-m-d H:i:s');
  if(preg_match("/(?=.*(`|phpinfo|system|exec|passthru|file_get_contents|readfile|dl|popen|proc_open|putenv|symlink|link|include|scan|dir|\^|\&|\||\[|.\(|~))(?=.*(\(|\)|ls|cat|index|drop|rm|\-|whoami|id|tail|head|echo|\=?\+\+|))/i",$payload) ) {
    $file = fopen("/var/log/webvuln.log","a");
    fwrite($file,"- [Time]: ".$date." #[Attacker's IP]: ".$_SERVER['REMOTE_ADDR']." #[Detected]: RCE attack!! # [Endpoint]: /".$method."/ = ".$endpoint." # [Payload]: ".$payload."\n");
    fclose($file);
  }

}

if((isset($_GET["page"]) &&!empty($_GET["page"]))&& $_GET["page"]!=="index"){

    $page=$_GET["page"];
    if(preg_match("/resource=Fffffff4ggggggg/i",$page)){
        die("Ok baby");
    }else{ 
	include("$page".".php");    	
    }
}else{
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Robot</title>

        <!-- CSS -->

        <!-- google fonts -->
        <link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>

        <!-- files -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/magnific-popup.css" rel="stylesheet">
        <link href="assets/css/owl.carousel.css" rel="stylesheet">
        <link href="assets/css/owl.carousel.theme.min.css" rel="stylesheet">
        <link href="assets/css/ionicons.css" rel="stylesheet">
        <link href="assets/css/main.css" rel="stylesheet">

        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>

    <!-- Site Header -->
        <div class="site-header-bg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <a href="?page=index"><img src="assets/images/logo.png" alt="logo"></a>
                    </div>
                    <div class="col-sm-3 col-sm-offset-3 text-right">
                        <span class="ion-android-cart"></span> 0 products
                        <form action="" method="get"><br>
                                          <label for="fname">Search:</label>
                                          <span>
                          <input style="color:black;width: 100px"  type="text" id="fname" name="search">
                          <input style="background: #FABE12;color:white" type="submit" value="Submit"></span>
                          
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
    <!-- Header -->

        <section id="header" class="main-header about-header inner-header">
            <div class="container">

                <div class="row">
                    <nav class="navbar navbar-default">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#site-nav-bar" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse" id="site-nav-bar">
                            <ul class="nav navbar-nav">
                                <li><a href="?page=index">Home</a></li>
                                <li class="active"><a href="?page=about">About</a></li>
                                <li><a href="?page=shop">Shop</a></li>
                                <li><a href="?page=faq">FAQ</a></li>
                                <li><a href="?page=contact">Contact</a></li>
                                <li><a href="?page=login">login</a></li>
                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </nav>
                </div>
                
                <div class="intro row">
                    <div class="overlay"></div>
                    <div class="col-sm-6 col-sm-offset-6">
                        <h2 class="header-quote">Save time and lower</h2>
                        <p>
                            Your sweeping costs with the
                        </p>
                        <h1 class="header-title">Robot<br><span class="thin">Factory</span></h1>
                    </div>
                </div> <!-- /.intro.row -->
            </div> <!-- /.container -->
            <div class="nutral"></div>
        </section> <!-- /#header -->

    <!-- Product -->

        <section id="product" class="product">
            <div class="container section-bg">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="title-box">
                            <h2 class="title">Welcom to our <span>Robot Factory</span></h2>
                            <a href="#" class="btn btn-default btn-robot">view products</a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="porduct-box">
                            <img class="img-responsive" src="assets/images/product-1.jpg" alt="product">
                            <h3 class="product-title">Space robot</h3>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="porduct-box">
                            <img class="img-responsive" src="assets/images/product-2.jpg" alt="product">
                            <h3 class="product-title">Sports robot</h3>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="porduct-box">
                            <img class="img-responsive" src="assets/images/product-3.jpg" alt="product">
                            <h3 class="product-title">Toy for kids</h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="classic-title">
                            <div class="stiker">
                                <h3 class="inner-stiker">Why we are best</h3>
                            </div>
                            <h3 class="outer-stiker">We Received best factory award in the 1998</h3>
                            <div class="incline-div"></div>
                        </div>
                    </div>
                    <div class="boxed">
                        <div class="col-sm-4">
                            <p class="p-large">
                                Sed lobortis volutpat imperdiet. faci.Fusce nec arcu ac neque tincidunt rutru tristique feugiat purus, id semper nisl tin vitae.Roin lobortis porta mattis. Mauris tincidunurus nec viverra mattis. Nunc convallis massa at eleifend blandit. Donec interdum.
                            </p>
                        </div>
                        <div class="col-sm-4">
                            <p>
                                Ead lobortis volutpat imperdiet. Nulla faci.Fusce nec arcu ac neque tincidunt rutrum. Pro tristique feugiat purus, id semper nisl tincidunt vitae.Roin lobortis porta mattis. Mauris tincidunt purus nec viverra mattis. Nunc convallis massa at eleifend blandit. Donec interdum, sem lacinia dignissime varius, nulla eros consectetur mauris. 
                            </p>
                        </div>
                        <div class="col-sm-4">
                            <p>
                                Sed lobortis volutpat imperdiet. Nulla faci.Fusce nec arcu ac neque tincidunt rutrum. Pro tristique feugiat purus, id semper nisl tincidunt vitae.Roin lobortis porta mattis. Mauris tincidunt purus nec viverra mattis. Nunc convallis massa at eleifend blandit. Donec interdum, sem lacinia dignissime varius, nulla eros consectetur mauris. 
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    <!-- History -->
        <section id="history" class="history">
            <div class="container section-bg">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="title-box">
                            <p>Since 1990</p>
                            <h2 class="title mt0">Discover our history</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="boxed">
                        <div class="col-sm-10 col-sm-offset-1">
                            <p>
                                Lorem ipsum dolor sit amet consectetuer adipiscing elit sed diam nonummynibh euismod tincidunt ut laoree Dolore magna aliquam erat volutpat.Lorem ipsum dolor sit amet consectetuer adipiscing elit sed diam nonummynibh euismod tincidunt ut laoree Dolore magna aliquam erat .
                            </p>
                        </div>
                        <div class="col-sm-12">
                            <img class="img-responsive" src="assets/images/history.png" alt="history">
                        </div>
                    </div>
                </div>
            </div>
        </section>

    <!-- Partner -->
        <section id="partner" class="partner">
            <div class="container section-bg">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="title-box">
                            <p>Our media</p>
                            <h2 class="title mt0">Partner</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="boxed">
                       <div class="col-sm-12">
                           <div id="partner-slider" class="owl-carousel">
                                <div class="item">
                                    <img src="assets/images/6.png" alt="partner">
                                </div>
                                <div class="item">
                                    <img src="assets/images/7.png" alt="partner">
                                </div>
                                <div class="item">
                                    <img src="assets/images/8.png" alt="partner">
                                </div>
                                <div class="item">
                                    <img src="assets/images/9.png" alt="partner">
                                </div>
                                <div class="item">
                                    <img src="assets/images/6.png" alt="partner">
                                </div>
                                <div class="item">
                                    <img src="assets/images/7.png" alt="partner">
                                </div>
                                <div class="item">
                                    <img src="assets/images/8.png" alt="partner">
                                </div>
                                <div class="item">
                                    <img src="assets/images/9.png" alt="partner">
                                </div>
                                <div class="item">
                                    <img src="assets/images/6.png" alt="partner">
                                </div>
                                <div class="item">
                                    <img src="assets/images/7.png" alt="partner">
                                </div>
                                <div class="item">
                                    <img src="assets/images/8.png" alt="partner">
                                </div>
                                <div class="item">
                                    <img src="assets/images/9.png" alt="partner">
                                </div>
                            </div>
                       </div>
                    </div>
                </div>
            </div>
        </section>


    <!-- Footer -->
        <section id="footer-widget" class="footer-widget">
            <div class="container header-bg">
                <div class="row">
                    <div class="col-sm-3">
                        <h3>Our Popular Services</h3>
                        <ul>
                            <li><a href="#">Space Robot</a></li>
                            <li><a href="#">Lego Robot</a></li>
                            <li><a href="#">Toy for Robot</a></li>
                            <li><a href="#">Industry Robot</a></li>
                            <li><a href="#">Sports Robot</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-3">
                        <h3>Important Link</h3>
                        <ul>
                            <li><a href="#">Lorem</a></li>
                            <li><a href="#">Ipsum</a></li>
                            <li><a href="#">Dolar</a></li>
                            <li><a href="#">Set amet</a></li>
                            <li><a href="#">Iodiet lorem</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-3">
                        <h3>Our Latest Services</h3>
                        <ul>
                            <li><a href="#">Edu Robot</a></li>
                            <li><a href="#">Low Robot</a></li>
                            <li><a href="#">Mega Robot</a></li>
                            <li><a href="#">Industry Robot</a></li>
                            <li><a href="#">Sports Robot</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-3">
                        <h3>Our Services</h3>
                        <div class="widget-img-box">
                            <a class="test-popup-link" href="assets/images/widget-big-1.png">
                                <img class="widget-img" src="assets/images/widget-1.png" alt="widget">
                            </a>
                            <a class="test-popup-link" href="assets/images/widget-big-2.png">
                                <img class="widget-img" src="assets/images/widget-2.png" alt="widget">
                            </a>
                            <a class="test-popup-link" href="assets/images/widget-big-3.png">
                                <img class="widget-img" src="assets/images/widget-3.png" alt="widget">
                            </a>
                            <a class="test-popup-link" href="assets/images/widget-big-4.png">
                                <img class="widget-img" src="assets/images/widget-4.png" alt="widget">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="footer text-center">
            <h3>&copy; Theme by <a href="https://themewagon.com/">Themewagon</a></h3>
        </footer>

    <!-- Scripts -->
        <script src="assets/js/jquery-1.12.3.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/script.js"></script>

    </body>
</html>

<?php }
//log for input 
foreach ($_GET as $endpoint => $payload) {
	dtXSS($endpoint,$payload,"GET");
	dtSQLI($endpoint,$payload,"GET");
	dtRCE($endpoint,$payload,"GET");
};
foreach ($_POST as $endpoint => $payload) {
        dtXSS($endpoint,$payload,"POST");
        dtSQLI($endpoint,$payload,"POST");
        dtRCE($endpoint,$payload,"POST");
};
?>
