<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Robot | About</title>

        <!-- CSS -->

        <!-- google fonts -->
        <link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>

        <!-- files -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/magnific-popup.css" rel="stylesheet">
        <link href="assets/css/owl.carousel.css" rel="stylesheet">
        <link href="assets/css/owl.carousel.theme.min.css" rel="stylesheet">
        <link href="assets/css/ionicons.css" rel="stylesheet">
        <link href="assets/css/main.css" rel="stylesheet">

        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>

    <!-- Site Header -->
        <div class="site-header-bg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <a href="?page=index"><img src="assets/images/logo.png" alt="logo"></a>
                    </div>
                    <div class="col-sm-3 col-sm-offset-3 text-right">
                        <span class="ion-android-cart"></span> 0 products
                        <form action="" method="get"><br>
                                          <label for="fname">Search:</label>
                                          <span>
                          <input style="color:black;width: 100px"  type="text" id="fname" name="search">
                          <input style="background: #FABE12;color:white" type="submit" value="Submit"></span>
                          
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
    <!-- Header -->

        <section id="header" class="main-header about-header inner-header">
            <div class="container">

                <div class="row">
                    <nav class="navbar navbar-default">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#site-nav-bar" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse" id="site-nav-bar">
                            <ul class="nav navbar-nav">
                                <li><a href="?page=index">Home</a></li>
                                <li class="active"><a href="?page=about">About</a></li>
                                <li><a href="?page=shop">Shop</a></li>
                                <li><a href="?page=faq">FAQ</a></li>
                                <li><a href="?page=contact">Contact</a></li>
                                <li><a href="?page=login">login</a></li>
                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </nav>
                </div>
                
                <div class="intro row">
                    <div class="overlay"></div>
                    <div class="col-sm-12">
                        <ol class="breadcrumb">
                            <li><a href="?page=index">Home</a></li>
                            <li class="active">About</li>
                        </ol>
                    </div>
                </div> <!-- /.intro.row -->
            </div> <!-- /.container -->
            <div class="nutral"></div>
        </section> <!-- /#header -->

    <!-- About -->
        <section class="about">
            <div class="container page-bgc">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="title-box">
                            <p>Feel free to</p>
                            <h2 class="title mt0">Know ourselfs</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="boxed">
                        <div class="col-sm-12">
                            <p class="inner-p">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                            </p>
                        </div>
                    </div>
                </div>

            <!-- Services -->
                <div class="service">
                    <div class="row">
                        <div class="boxed">
                            <div class="col-sm-4">
                                <div class="service-box">
                                    <div class="service-title">
                                        <div class="icon">
                                            <span class="ion-ios-monitor"></span>
                                        </div>
                                         <div class="mt-10">
                                            DIY-Friendly
                                        </div>
                                    </div>
                                    <p>
                                        Class aptent taciti sociosqu litora torquent conubia nos per inceptos himenaeo Lorem Ipsum is simply dummy text.
                                    </p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="service-box">
                                    <div class="service-title">
                                        <div class="icon">
                                            <span class="ion-person"></span>
                                        </div>
                                         <div class="mt-10">
                                            Amazing support
                                        </div>
                                    </div>
                                    <p>
                                        Class aptent taciti sociosqu litora torquent conubia nos per inceptos himenaeo Lorem Ipsum is simply dummy text.
                                    </p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="service-box">
                                    <div class="service-title">
                                        <div class="icon">
                                            <span class="ion-ios-cloud-upload"></span>
                                        </div>
                                         <div>
                                            In the cloud
                                        </div>
                                    </div>
                                    <p>
                                        Class aptent taciti sociosqu litora torquent conubia nos per inceptos himenaeo Lorem Ipsum is simply dummy text.
                                    </p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="service-box">
                                    <div class="service-title">
                                        <div class="icon">
                                            <span class="ion-android-options"></span>
                                        </div>
                                         <div class="mt-10">
                                            Flexible
                                        </div>
                                    </div>
                                    <p>
                                        Class aptent taciti sociosqu litora torquent conubia nos per inceptos himenaeo Lorem Ipsum is simply dummy text.
                                    </p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="service-box">
                                    <div class="service-title">
                                        <div class="icon">
                                            <span class="ion-ios-color-wand"></span>
                                        </div>
                                         <div class="mt-10">
                                            Economical
                                        </div>
                                    </div>
                                    <p>
                                        Class aptent taciti sociosqu litora torquent conubia nos per inceptos himenaeo Lorem Ipsum is simply dummy text.
                                    </p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="service-box">
                                    <div class="service-title">
                                        <div class="icon">
                                            <span class="ion-ios-cog"></span>
                                        </div>
                                         <div class="mt-10">
                                            Customizable
                                        </div>
                                    </div>
                                    <p>
                                        Class aptent taciti sociosqu litora torquent conubia nos per inceptos himenaeo Lorem Ipsum is simply dummy text.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <!-- Machine Man -->
                <div class="machine-man">
                    <div class="row">
                        <div class="boxed">
                            <div class="col-sm-8">
                                <h4 class="m-s-title">CES 2015 Control Product of the Year</h4>
                                <h1 class="m-p-title">Convert your smart device into the ultimate remote control</h1>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                                    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

            <!-- Team -->
                <div class="team">
                    <div class="row">
                        <div class="boxed">
                            <div class="col-sm-12">
                                <div class="title-box">
                                    <p>Meet our</p>
                                    <h2 class="title mt0">Team Members</h2>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="team-box">
                                    <div class="team-img">
                                        <img class="team-img img-responsive" src="assets/images/team-1.png" alt="team">
                                    </div>
                                    <div class="team-img-detail">
                                        <h4 class="member-name">Jonathan Smith</h4>
                                        <h5 class="member-id">Founder &amp; CEO</h5>
                                        <p>
                                            Donec vehicula imperdiet justo, non viverra sapien egestas a. Aliquam ut sodales felis, eget iaculis erat.
                                        </p>
                                        <div class="social">
                                            <a href="#"><i class="ion-social-facebook"></i></a>
                                            <a href="#"><i class="ion-social-twitter"></i></a>
                                            <a href="#"><i class="ion-social-linkedin"></i></a>
                                            <a href="#"><i class="ion-social-googleplus"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="team-box">
                                    <div class="team-img">
                                        <img class="team-img img-responsive" src="assets/images/team-2.png" alt="team">
                                    </div>
                                    <div class="team-img-detail">
                                        <h4 class="member-name">Jonathan Smith</h4>
                                        <h5 class="member-id">Founder &amp; CEO</h5>
                                        <p>
                                            Donec vehicula imperdiet justo, non viverra sapien egestas a. Aliquam ut sodales felis, eget iaculis erat.
                                        </p>
                                        <div class="social">
                                            <a href="#"><i class="ion-social-facebook"></i></a>
                                            <a href="#"><i class="ion-social-twitter"></i></a>
                                            <a href="#"><i class="ion-social-linkedin"></i></a>
                                            <a href="#"><i class="ion-social-googleplus"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="team-box">
                                    <div class="team-img">
                                        <img class="team-img img-responsive" src="assets/images/team-3.png" alt="team">
                                    </div>
                                    <div class="team-img-detail">
                                        <h4 class="member-name">Jonathan Smith</h4>
                                        <h5 class="member-id">Founder &amp; CEO</h5>
                                        <p>
                                            Donec vehicula imperdiet justo, non viverra sapien egestas a. Aliquam ut sodales felis, eget iaculis erat.
                                        </p>
                                        <div class="social">
                                            <a href="#"><i class="ion-social-facebook"></i></a>
                                            <a href="#"><i class="ion-social-twitter"></i></a>
                                            <a href="#"><i class="ion-social-linkedin"></i></a>
                                            <a href="#"><i class="ion-social-googleplus"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="team-box">
                                    <div class="team-img">
                                        <img class="team-img img-responsive" src="assets/images/team-4.png" alt="team">
                                    </div>
                                    <div class="team-img-detail">
                                        <h4 class="member-name">Jonathan Smith</h4>
                                        <h5 class="member-id">Founder &amp; CEO</h5>
                                        <p>
                                            Donec vehicula imperdiet justo, non viverra sapien egestas a. Aliquam ut sodales felis, eget iaculis erat.
                                        </p>
                                        <div class="social">
                                            <a href="#"><i class="ion-social-facebook"></i></a>
                                            <a href="#"><i class="ion-social-twitter"></i></a>
                                            <a href="#"><i class="ion-social-linkedin"></i></a>
                                            <a href="#"><i class="ion-social-googleplus"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="team-box">
                                    <div class="team-img">
                                        <img class="team-img img-responsive" src="assets/images/team-5.png" alt="team">
                                    </div>
                                    <div class="team-img-detail">
                                        <h4 class="member-name">Jonathan Smith</h4>
                                        <h5 class="member-id">Founder &amp; CEO</h5>
                                        <p>
                                            Donec vehicula imperdiet justo, non viverra sapien egestas a. Aliquam ut sodales felis, eget iaculis erat.
                                        </p>
                                        <div class="social">
                                            <a href="#"><i class="ion-social-facebook"></i></a>
                                            <a href="#"><i class="ion-social-twitter"></i></a>
                                            <a href="#"><i class="ion-social-linkedin"></i></a>
                                            <a href="#"><i class="ion-social-googleplus"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="team-box">
                                    <div class="team-img">
                                        <img class="team-img img-responsive" src="assets/images/team-6.png" alt="team">
                                    </div>
                                    <div class="team-img-detail">
                                        <h4 class="member-name">Jonathan Smith</h4>
                                        <h5 class="member-id">Founder &amp; CEO</h5>
                                        <p>
                                            Donec vehicula imperdiet justo, non viverra sapien egestas a. Aliquam ut sodales felis, eget iaculis erat.
                                        </p>
                                        <div class="social">
                                            <a href="#"><i class="ion-social-facebook"></i></a>
                                            <a href="#"><i class="ion-social-twitter"></i></a>
                                            <a href="#"><i class="ion-social-linkedin"></i></a>
                                            <a href="#"><i class="ion-social-googleplus"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <!-- CTA -->
                <div class="cta">
                    <div class="row">
                        <div class="boxed">
                            <div class="col-sm-9">
                                <p>
                                    If you love creating professional, beautiful and simple Robot or modify robot skills to help quickly and efficiently, then we can’t wait to welcome you onto our team.
                                </p>
                            </div>
                            <div class="col-sm-3">
                                <a class="btn btn-robot btn-block" href="#">Send us your resume</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>

    <!-- Footer -->
        <section id="footer-widget" class="footer-widget">
            <div class="container header-bg">
                <div class="row">
                    <div class="col-sm-3">
                        <h3>Our Popular Services</h3>
                        <ul>
                            <li><a href="#">Space Robot</a></li>
                            <li><a href="#">Lego Robot</a></li>
                            <li><a href="#">Toy for Robot</a></li>
                            <li><a href="#">Industry Robot</a></li>
                            <li><a href="#">Sports Robot</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-3">
                        <h3>Important Link</h3>
                        <ul>
                            <li><a href="#">Lorem</a></li>
                            <li><a href="#">Ipsum</a></li>
                            <li><a href="#">Dolar</a></li>
                            <li><a href="#">Set amet</a></li>
                            <li><a href="#">Iodiet lorem</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-3">
                        <h3>Our Latest Services</h3>
                        <ul>
                            <li><a href="#">Edu Robot</a></li>
                            <li><a href="#">Low Robot</a></li>
                            <li><a href="#">Mega Robot</a></li>
                            <li><a href="#">Industry Robot</a></li>
                            <li><a href="#">Sports Robot</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-3">
                        <h3>Our Services</h3>
                        <div class="widget-img-box">
                            <a class="test-popup-link" href="assets/images/widget-big-1.png">
                                <img class="widget-img" src="assets/images/widget-1.png" alt="widget">
                            </a>
                            <a class="test-popup-link" href="assets/images/widget-big-2.png">
                                <img class="widget-img" src="assets/images/widget-2.png" alt="widget">
                            </a>
                            <a class="test-popup-link" href="assets/images/widget-big-3.png">
                                <img class="widget-img" src="assets/images/widget-3.png" alt="widget">
                            </a>
                            <a class="test-popup-link" href="assets/images/widget-big-4.png">
                                <img class="widget-img" src="assets/images/widget-4.png" alt="widget">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="footer text-center">
            <h3>&copy; Theme by <a href="https://themewagon.com/">Themewagon</a></h3>
        </footer>

    <!-- Scripts -->
        <script src="assets/js/jquery-1.12.3.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/script.js"></script>

    </body>
</html>