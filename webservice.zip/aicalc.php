<?php
$calc=0;
if(isset($_POST['calc']) && !empty($_POST['calc'])){
	$calc=$_POST['calc'];
}

?>


<!DOCTYPE html>
<html>
<head>
	<title>AI CALCULATOR</title>
</head>
<body style="background-image: url('assets/images/ai.jpg');background-repeat: no-repeat;background-attachment: fixed;
  background-size: cover; ">

  <div style="width: 800px;height: 600px;  ">
  	<center style="color: white;margin-top: 100px"><h1 >AI CALCULATOR<h1>
  		<br><br>
  			
  			<form action="" method="post">
  				<input style="width: 500px;height: 40px;font-size: 25px; border-radius: 15px" placeholder="Ex: 4*4+4+4" type="text" name="calc"><br><br>
  				<button style="cursor: pointer;width: 100px;height: 50px;font-size: 30px;background: #FABE12;border-radius: 15px">calc</button>

  			</form>
		<?php if($calc!==0){ ?>
  		<div >
  			<h3>Result:</h3>
  			<div style="width: 300px; height: 300px"><?php eval("echo ".$calc.";") ?> <div>		
  		</div>
		<?php }?>
  	</center>
  </div>

</body>
</html>
